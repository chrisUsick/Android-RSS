package com.cu_dev.androidrss;

import android.database.Observable;
import android.databinding.ObservableField;

/**
 * Created by chris on 07-Oct-16.
 */
public class ListViewModel {
    public final ObservableField<String> feedName = new ObservableField<>();
}
