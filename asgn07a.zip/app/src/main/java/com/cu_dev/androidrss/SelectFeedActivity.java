package com.cu_dev.androidrss;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.cu_dev.androidrss.model.Feed;

import java.util.ArrayList;
import java.util.Arrays;

public class SelectFeedActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String TAG = "SelectFeedActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_feed);

        initFeedSelector();
    }

    private void initFeedSelector() {
        Spinner spinner = (Spinner)findViewById(R.id.feed_selector);
        ArrayAdapter<Feed> adapter = new ArrayAdapter<Feed>(
                this, android.R.layout.simple_spinner_item,
                loadFeeds().toArray(new Feed[0])
        );
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(this);
    }

    private ArrayList<Feed> loadFeeds() {
        ArrayList<Feed> feeds = new ArrayList<>(Arrays.asList(
                new Feed("Default", "https://news.google.com/news?cf=all&hl=en&pz=1&ned=ca&output=rss")
        ));
        return feeds;
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Feed feed = (Feed)adapterView.getSelectedItem();
        Log.i(TAG, "item selected: " + feed.getName());

    }

    private void startListActivity(Feed feed) {
        Intent intent = new Intent(this, ListActivity.class);
        intent.putExtra(getString(R.string.extra_feed), feed);
        startActivity(intent);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        Log.i(TAG, "Nothing selected");
    }

    public void loadFeed(View view) {
        Log.i(TAG, "Loading feed");
        Spinner spinner = (Spinner)findViewById(R.id.feed_selector);
        Feed feed = (Feed)spinner.getSelectedItem();
        startListActivity(feed);
    }
}
