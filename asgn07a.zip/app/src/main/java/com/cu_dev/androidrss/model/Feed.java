package com.cu_dev.androidrss.model;

import java.io.Serializable;

/**
 * Created by chris on 07-Oct-16.
 */
public class Feed implements Serializable {
    private String name;
    private String uri;

    public Feed(String name, String uri) {
        this.name = name;
        this.uri = uri;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    @Override
    public String toString() {
        return getName();
    }
}
