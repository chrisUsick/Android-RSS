package com.cu_dev.androidrss;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;

import com.cu_dev.androidrss.databinding.ActivityDetailBinding;

public class DetailActivity extends AppCompatActivity {

    private static final String TAG = "DetailActivity";
    private ActivityDetailBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        loadRssEntry();
    }

    private void loadRssEntry() {
        Intent intent = getIntent();
        FeedDetail feedDetail = (FeedDetail)intent.getSerializableExtra(getString(R.string.extra_feed_detail));
        initBinding(feedDetail);
        setWebView(feedDetail.description.get());
        Log.i(TAG, "Loading details of: " + feedDetail.title.get());
    }

    private void setWebView(String description) {
        WebView wv = (WebView)findViewById(R.id.description_webview);
        wv.loadData(description, "text/html", null);
    }

    private void initBinding(FeedDetail feedDetail) {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_detail);
        binding.setViewModel(feedDetail);
    }
}
