package com.cu_dev.androidrss;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.cu_dev.androidrss.databinding.ActivityListBinding;
import com.cu_dev.androidrss.model.Feed;
import com.rometools.rome.feed.synd.SyndEntry;
import com.rometools.rome.feed.synd.SyndFeed;

public class ListActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private static final String TAG = "ListActivity";
    private Feed feed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        feed = this.feedFromIntent();

        ActivityListBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_list);
        ListViewModel viewModel = new ListViewModel();
        viewModel.feedName.set(feed.getName());
        binding.setViewModel(viewModel);

        loadRss();
    }

    private void loadRss() {
        new LoadFeedTask(this, feed).execute();

    }

    private Feed feedFromIntent() {
        Intent intent = getIntent();
         return (Feed)intent.getSerializableExtra(getString(R.string.extra_feed));
    }

    public void populateListView(SyndFeed feed) {
        ListView listView = (ListView)findViewById(R.id.feed_list);
        ArrayAdapter<SyndEntry> adapter = new SyndEntryAdapter(
                this, R.layout.rss_feed_list_item,
                feed.getEntries().toArray(new SyndEntry[0]));

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        viewDetails((SyndEntry)adapterView.getItemAtPosition(position));
    }

    private void viewDetails(SyndEntry selectedItem) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra(getString(R.string.extra_feed_detail), new FeedDetail(selectedItem));
        Log.i(TAG, "Loading details");
        startActivity(intent);
    }
}
